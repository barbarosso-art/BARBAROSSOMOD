# BARBAROSSOMOD v0.1 — PC

BSIPA-плагин для Beat Saber 1.40.8. Загружает изображение только из папки
текущей пользовательской карты по секции `_customData._mapImage` в `Info.dat`.
Другие карты и меню не получают фон этой карты.

Публичный ID: `BARBAROSSOMOD`. Версия: `0.1.0`.

## Установка

Скопировать в `Plugins` экземпляра Beat Saber 1.40.8:

- `BARBAROSSOMOD.dll`;
- `MapImagePCAssets.bundle`.

Зависимости: BSIPA 4.3.6 и SiraUtil 3.0.5 или совместимые версии.

Переключатель: `UserData\BARBAROSSOMOD.json`:

```json
{"Enabled": true}
```

Старый `UserData\MapImage.json` поддерживается для обратной совместимости.

Сборка и установка: `build.ps1 -Install`.
